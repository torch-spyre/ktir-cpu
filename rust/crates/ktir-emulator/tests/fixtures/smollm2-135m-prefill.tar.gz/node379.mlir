module {
  func.func @ktir_prefill_smollm2_135m_n379(%t711_ptr: index, %t714_ptr: index, %t5_ptr: index, %t6_ptr: index) attributes {grid = [1, 1]} {
    %c0 = arith.constant 0 : index
    %half0 = arith.constant 32 : index
    %view1 = ktdp.construct_memory_view %t711_ptr, sizes: [72, 64], strides: [64, 1] {
      coordinate_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 71 >= 0, d1 >= 0, -d1 + 63 >= 0)>,
      memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<72x64xf16>
    %view2 = ktdp.construct_memory_view %t714_ptr, sizes: [72, 64], strides: [64, 1] {
      coordinate_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 71 >= 0, d1 >= 0, -d1 + 63 >= 0)>,
      memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<72x64xf16>
    %acc3 = ktdp.construct_access_tile %view1[%c0, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v4 = ktdp.load %acc3 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc5 = ktdp.construct_access_tile %view1[%c0, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v6 = ktdp.load %acc5 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view7 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %acc8 = ktdp.construct_access_tile %view7[%c0] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v9 = ktdp.load %acc8 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi10 = tensor.empty() : tensor<9x32xf16>
    %cosb11 = linalg.broadcast ins(%v9 : tensor<32xf16>) outs(%cbi10 : tensor<9x32xf16>) dimensions = [0]
    %view12 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %acc13 = ktdp.construct_access_tile %view12[%c0] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v14 = ktdp.load %acc13 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi15 = tensor.empty() : tensor<9x32xf16>
    %sinb16 = linalg.broadcast ins(%v14 : tensor<32xf16>) outs(%cbi15 : tensor<9x32xf16>) dimensions = [0]
    %a117 = arith.mulf %v4, %cosb11 : tensor<9x32xf16>
    %a218 = arith.mulf %v6, %sinb16 : tensor<9x32xf16>
    %of19 = arith.subf %a117, %a218 : tensor<9x32xf16>
    %b120 = arith.mulf %v4, %sinb16 : tensor<9x32xf16>
    %b221 = arith.mulf %v6, %cosb11 : tensor<9x32xf16>
    %os22 = arith.addf %b120, %b221 : tensor<9x32xf16>
    %acc23 = ktdp.construct_access_tile %view2[%c0, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of19, %acc23 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc24 = ktdp.construct_access_tile %view2[%c0, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os22, %acc24 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off25 = arith.constant 9 : index
    %acc26 = ktdp.construct_access_tile %view1[%off25, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v27 = ktdp.load %acc26 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc28 = ktdp.construct_access_tile %view1[%off25, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v29 = ktdp.load %acc28 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view30 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off31 = arith.constant 64 : index
    %acc32 = ktdp.construct_access_tile %view30[%off31] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v33 = ktdp.load %acc32 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi34 = tensor.empty() : tensor<9x32xf16>
    %cosb35 = linalg.broadcast ins(%v33 : tensor<32xf16>) outs(%cbi34 : tensor<9x32xf16>) dimensions = [0]
    %view36 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off37 = arith.constant 64 : index
    %acc38 = ktdp.construct_access_tile %view36[%off37] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v39 = ktdp.load %acc38 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi40 = tensor.empty() : tensor<9x32xf16>
    %sinb41 = linalg.broadcast ins(%v39 : tensor<32xf16>) outs(%cbi40 : tensor<9x32xf16>) dimensions = [0]
    %a142 = arith.mulf %v27, %cosb35 : tensor<9x32xf16>
    %a243 = arith.mulf %v29, %sinb41 : tensor<9x32xf16>
    %of44 = arith.subf %a142, %a243 : tensor<9x32xf16>
    %b145 = arith.mulf %v27, %sinb41 : tensor<9x32xf16>
    %b246 = arith.mulf %v29, %cosb35 : tensor<9x32xf16>
    %os47 = arith.addf %b145, %b246 : tensor<9x32xf16>
    %acc48 = ktdp.construct_access_tile %view2[%off25, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of44, %acc48 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc49 = ktdp.construct_access_tile %view2[%off25, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os47, %acc49 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off50 = arith.constant 18 : index
    %acc51 = ktdp.construct_access_tile %view1[%off50, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v52 = ktdp.load %acc51 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc53 = ktdp.construct_access_tile %view1[%off50, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v54 = ktdp.load %acc53 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view55 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off56 = arith.constant 128 : index
    %acc57 = ktdp.construct_access_tile %view55[%off56] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v58 = ktdp.load %acc57 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi59 = tensor.empty() : tensor<9x32xf16>
    %cosb60 = linalg.broadcast ins(%v58 : tensor<32xf16>) outs(%cbi59 : tensor<9x32xf16>) dimensions = [0]
    %view61 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off62 = arith.constant 128 : index
    %acc63 = ktdp.construct_access_tile %view61[%off62] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v64 = ktdp.load %acc63 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi65 = tensor.empty() : tensor<9x32xf16>
    %sinb66 = linalg.broadcast ins(%v64 : tensor<32xf16>) outs(%cbi65 : tensor<9x32xf16>) dimensions = [0]
    %a167 = arith.mulf %v52, %cosb60 : tensor<9x32xf16>
    %a268 = arith.mulf %v54, %sinb66 : tensor<9x32xf16>
    %of69 = arith.subf %a167, %a268 : tensor<9x32xf16>
    %b170 = arith.mulf %v52, %sinb66 : tensor<9x32xf16>
    %b271 = arith.mulf %v54, %cosb60 : tensor<9x32xf16>
    %os72 = arith.addf %b170, %b271 : tensor<9x32xf16>
    %acc73 = ktdp.construct_access_tile %view2[%off50, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of69, %acc73 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc74 = ktdp.construct_access_tile %view2[%off50, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os72, %acc74 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off75 = arith.constant 27 : index
    %acc76 = ktdp.construct_access_tile %view1[%off75, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v77 = ktdp.load %acc76 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc78 = ktdp.construct_access_tile %view1[%off75, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v79 = ktdp.load %acc78 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view80 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off81 = arith.constant 192 : index
    %acc82 = ktdp.construct_access_tile %view80[%off81] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v83 = ktdp.load %acc82 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi84 = tensor.empty() : tensor<9x32xf16>
    %cosb85 = linalg.broadcast ins(%v83 : tensor<32xf16>) outs(%cbi84 : tensor<9x32xf16>) dimensions = [0]
    %view86 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off87 = arith.constant 192 : index
    %acc88 = ktdp.construct_access_tile %view86[%off87] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v89 = ktdp.load %acc88 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi90 = tensor.empty() : tensor<9x32xf16>
    %sinb91 = linalg.broadcast ins(%v89 : tensor<32xf16>) outs(%cbi90 : tensor<9x32xf16>) dimensions = [0]
    %a192 = arith.mulf %v77, %cosb85 : tensor<9x32xf16>
    %a293 = arith.mulf %v79, %sinb91 : tensor<9x32xf16>
    %of94 = arith.subf %a192, %a293 : tensor<9x32xf16>
    %b195 = arith.mulf %v77, %sinb91 : tensor<9x32xf16>
    %b296 = arith.mulf %v79, %cosb85 : tensor<9x32xf16>
    %os97 = arith.addf %b195, %b296 : tensor<9x32xf16>
    %acc98 = ktdp.construct_access_tile %view2[%off75, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of94, %acc98 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc99 = ktdp.construct_access_tile %view2[%off75, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os97, %acc99 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off100 = arith.constant 36 : index
    %acc101 = ktdp.construct_access_tile %view1[%off100, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v102 = ktdp.load %acc101 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc103 = ktdp.construct_access_tile %view1[%off100, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v104 = ktdp.load %acc103 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view105 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off106 = arith.constant 256 : index
    %acc107 = ktdp.construct_access_tile %view105[%off106] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v108 = ktdp.load %acc107 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi109 = tensor.empty() : tensor<9x32xf16>
    %cosb110 = linalg.broadcast ins(%v108 : tensor<32xf16>) outs(%cbi109 : tensor<9x32xf16>) dimensions = [0]
    %view111 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off112 = arith.constant 256 : index
    %acc113 = ktdp.construct_access_tile %view111[%off112] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v114 = ktdp.load %acc113 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi115 = tensor.empty() : tensor<9x32xf16>
    %sinb116 = linalg.broadcast ins(%v114 : tensor<32xf16>) outs(%cbi115 : tensor<9x32xf16>) dimensions = [0]
    %a1117 = arith.mulf %v102, %cosb110 : tensor<9x32xf16>
    %a2118 = arith.mulf %v104, %sinb116 : tensor<9x32xf16>
    %of119 = arith.subf %a1117, %a2118 : tensor<9x32xf16>
    %b1120 = arith.mulf %v102, %sinb116 : tensor<9x32xf16>
    %b2121 = arith.mulf %v104, %cosb110 : tensor<9x32xf16>
    %os122 = arith.addf %b1120, %b2121 : tensor<9x32xf16>
    %acc123 = ktdp.construct_access_tile %view2[%off100, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of119, %acc123 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc124 = ktdp.construct_access_tile %view2[%off100, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os122, %acc124 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off125 = arith.constant 45 : index
    %acc126 = ktdp.construct_access_tile %view1[%off125, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v127 = ktdp.load %acc126 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc128 = ktdp.construct_access_tile %view1[%off125, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v129 = ktdp.load %acc128 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view130 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off131 = arith.constant 320 : index
    %acc132 = ktdp.construct_access_tile %view130[%off131] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v133 = ktdp.load %acc132 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi134 = tensor.empty() : tensor<9x32xf16>
    %cosb135 = linalg.broadcast ins(%v133 : tensor<32xf16>) outs(%cbi134 : tensor<9x32xf16>) dimensions = [0]
    %view136 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off137 = arith.constant 320 : index
    %acc138 = ktdp.construct_access_tile %view136[%off137] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v139 = ktdp.load %acc138 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi140 = tensor.empty() : tensor<9x32xf16>
    %sinb141 = linalg.broadcast ins(%v139 : tensor<32xf16>) outs(%cbi140 : tensor<9x32xf16>) dimensions = [0]
    %a1142 = arith.mulf %v127, %cosb135 : tensor<9x32xf16>
    %a2143 = arith.mulf %v129, %sinb141 : tensor<9x32xf16>
    %of144 = arith.subf %a1142, %a2143 : tensor<9x32xf16>
    %b1145 = arith.mulf %v127, %sinb141 : tensor<9x32xf16>
    %b2146 = arith.mulf %v129, %cosb135 : tensor<9x32xf16>
    %os147 = arith.addf %b1145, %b2146 : tensor<9x32xf16>
    %acc148 = ktdp.construct_access_tile %view2[%off125, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of144, %acc148 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc149 = ktdp.construct_access_tile %view2[%off125, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os147, %acc149 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off150 = arith.constant 54 : index
    %acc151 = ktdp.construct_access_tile %view1[%off150, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v152 = ktdp.load %acc151 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc153 = ktdp.construct_access_tile %view1[%off150, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v154 = ktdp.load %acc153 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view155 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off156 = arith.constant 384 : index
    %acc157 = ktdp.construct_access_tile %view155[%off156] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v158 = ktdp.load %acc157 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi159 = tensor.empty() : tensor<9x32xf16>
    %cosb160 = linalg.broadcast ins(%v158 : tensor<32xf16>) outs(%cbi159 : tensor<9x32xf16>) dimensions = [0]
    %view161 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off162 = arith.constant 384 : index
    %acc163 = ktdp.construct_access_tile %view161[%off162] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v164 = ktdp.load %acc163 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi165 = tensor.empty() : tensor<9x32xf16>
    %sinb166 = linalg.broadcast ins(%v164 : tensor<32xf16>) outs(%cbi165 : tensor<9x32xf16>) dimensions = [0]
    %a1167 = arith.mulf %v152, %cosb160 : tensor<9x32xf16>
    %a2168 = arith.mulf %v154, %sinb166 : tensor<9x32xf16>
    %of169 = arith.subf %a1167, %a2168 : tensor<9x32xf16>
    %b1170 = arith.mulf %v152, %sinb166 : tensor<9x32xf16>
    %b2171 = arith.mulf %v154, %cosb160 : tensor<9x32xf16>
    %os172 = arith.addf %b1170, %b2171 : tensor<9x32xf16>
    %acc173 = ktdp.construct_access_tile %view2[%off150, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of169, %acc173 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc174 = ktdp.construct_access_tile %view2[%off150, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os172, %acc174 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %off175 = arith.constant 63 : index
    %acc176 = ktdp.construct_access_tile %view1[%off175, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v177 = ktdp.load %acc176 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %acc178 = ktdp.construct_access_tile %view1[%off175, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    %v179 = ktdp.load %acc178 : !ktdp.access_tile<9x32xindex> -> tensor<9x32xf16>
    %view180 = ktdp.construct_memory_view %t5_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off181 = arith.constant 448 : index
    %acc182 = ktdp.construct_access_tile %view180[%off181] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v183 = ktdp.load %acc182 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi184 = tensor.empty() : tensor<9x32xf16>
    %cosb185 = linalg.broadcast ins(%v183 : tensor<32xf16>) outs(%cbi184 : tensor<9x32xf16>) dimensions = [0]
    %view186 = ktdp.construct_memory_view %t6_ptr, sizes: [512], strides: [1] {
      coordinate_set = affine_set<(d0) : (d0 >= 0, -d0 + 511 >= 0)>, memory_space = #ktdp.spyre_memory_space<HBM>
    } : memref<512xf16>
    %off187 = arith.constant 448 : index
    %acc188 = ktdp.construct_access_tile %view186[%off187] {
      access_tile_set = affine_set<(d0) : (d0 >= 0, -d0 + 31 >= 0)>,
      access_tile_order = affine_map<(d0) -> (d0)>
    } : memref<512xf16> -> !ktdp.access_tile<32xindex>
    %v189 = ktdp.load %acc188 : !ktdp.access_tile<32xindex> -> tensor<32xf16>
    %cbi190 = tensor.empty() : tensor<9x32xf16>
    %sinb191 = linalg.broadcast ins(%v189 : tensor<32xf16>) outs(%cbi190 : tensor<9x32xf16>) dimensions = [0]
    %a1192 = arith.mulf %v177, %cosb185 : tensor<9x32xf16>
    %a2193 = arith.mulf %v179, %sinb191 : tensor<9x32xf16>
    %of194 = arith.subf %a1192, %a2193 : tensor<9x32xf16>
    %b1195 = arith.mulf %v177, %sinb191 : tensor<9x32xf16>
    %b2196 = arith.mulf %v179, %cosb185 : tensor<9x32xf16>
    %os197 = arith.addf %b1195, %b2196 : tensor<9x32xf16>
    %acc198 = ktdp.construct_access_tile %view2[%off175, %c0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %of194, %acc198 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    %acc199 = ktdp.construct_access_tile %view2[%off175, %half0] {
      access_tile_set = affine_set<(d0, d1) : (d0 >= 0, -d0 + 8 >= 0, d1 >= 0, -d1 + 31 >= 0)>,
      access_tile_order = affine_map<(d0, d1) -> (d0, d1)>
    } : memref<72x64xf16> -> !ktdp.access_tile<9x32xindex>
    ktdp.store %os197, %acc199 : tensor<9x32xf16>, !ktdp.access_tile<9x32xindex>
    return
  }
}
